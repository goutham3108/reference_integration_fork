<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->
---
applyTo: "**"
---

# Contributing

Follow [CONTRIBUTION.md](../../CONTRIBUTION.md):
- Use provided PR templates
  - [bug_fix.md](../PULL_REQUEST_TEMPLATE/bug_fix.md)
  - [improvement.md](../PULL_REQUEST_TEMPLATE/improvement.md)
