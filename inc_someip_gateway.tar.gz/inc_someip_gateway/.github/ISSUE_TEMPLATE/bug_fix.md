<!--
*******************************************************************************
Copyright (c) 2026 Contributors to the Eclipse Foundation

See the NOTICE file(s) distributed with this work for additional
information regarding copyright ownership.

This program and the accompanying materials are made available under the
terms of the Apache License Version 2.0 which is available at
https://www.apache.org/licenses/LICENSE-2.0

SPDX-License-Identifier: Apache-2.0
*******************************************************************************
-->

---
name: Bugfix
about: 'Issue to track a bugfix'
title: 'Bugfix: Your bugfix title'
labels: 'codeowner_review'
assignees: ''

---

> [!IMPORTANT]
> Make sure to link this issue with the PR for your bugfix.
