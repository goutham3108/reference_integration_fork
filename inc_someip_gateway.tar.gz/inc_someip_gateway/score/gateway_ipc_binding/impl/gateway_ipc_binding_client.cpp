/********************************************************************************
 * Copyright (c) 2026 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/

#include "score/gateway_ipc_binding/gateway_ipc_binding_client.hpp"

#include <atomic>
#include <cerrno>
#include <iostream>
#include <memory>
#include <score/assert.hpp>
#include <string_view>
#include <thread>
#include <utility>

#include "binding_base.hpp"
#include "reply_channel.hpp"
#include "score/gateway_ipc_binding/error.hpp"
#include "score/gateway_ipc_binding/gateway_ipc_binding.hpp"
#include "score/socom/runtime.hpp"

namespace score::gateway_ipc_binding {

namespace {

/// \brief Implementation of Gateway_ipc_binding_client
class Gateway_ipc_binding_client_impl : public Gateway_ipc_binding_client, public Reply_channel {
   public:
    /// \brief Constructor
    /// \param runtime SOCom runtime instance
    /// \param channel Unique pointer to bidirectional channel client
    /// \param slot_manager Unique pointer to shared memory slot manager
    /// \param find_service_elements Service elements to advertise
    /// \param server_shared_memory_configs Shared memory configuration to send to the server
    Gateway_ipc_binding_client_impl(
        score::socom::Runtime& runtime,
        score::cpp::pmr::unique_ptr<score::message_passing::IClientConnection> channel,
        Shared_memory_manager_factory::Sptr slot_manager,
        Find_service_elements find_service_elements, Client_identifier identifier,
        Shared_memory_configs server_shared_memory_configs)
        : m_binding_base{runtime, std::move(slot_manager)},
          m_channel(std::move(channel)),
          m_find_service_elements(find_service_elements),
          m_identifier(identifier),
          m_server_shared_memory_configs(server_shared_memory_configs) {
        m_channel->Start([this](auto const state) { on_state_change(state); },
                         [this](auto const data) { on_receive_message(data); });
    }

    ~Gateway_ipc_binding_client_impl() {
        // ensure no callbacks are in-flight that might access member variables after they've been
        // destroyed.
        // Stop() uses a CAS that only succeeds when stop_reason_ is kNone. During an active
        // reconnect cycle (disconnect → auto-restart), stop_reason_ is transiently non-kNone,
        // causing Stop() to be a no-op. Retry until the channel reaches the stopped state.
        while (!m_stopped) {
            m_channel->Stop();
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }

    Result<void> send(score::cpp::span<std::uint8_t const> data) noexcept override {
        if (m_channel == nullptr) {
            return MakeUnexpected(Bidirectional_channel_error::runtime_error_send_failed,
                                  "Channel is not available");
        }

        auto const send_result = m_channel->Send(data);
        if (!send_result) {
            std::cerr << __PRETTY_FUNCTION__
                      << ": Failed to send message to server: " << send_result.error() << std::endl;
            if (send_result.error().GetOsDependentErrorCode() == EMSGSIZE) {
                // Unrecoverable: this message will never fit, retrying/reconnecting can't help.
                // Stop instead of leaving the peer waiting forever for a reply that can never
                // arrive.
                request_disconnect();
            }
            return MakeUnexpected(Bidirectional_channel_error::runtime_error_send_failed);
        }
        return {};
    }

    using Reply_channel::send;  // Bring template send() into scope

    void request_disconnect() noexcept override { m_channel->Stop(); }

    bool is_connected() const noexcept override { return m_connected; }

    void on_state_change(score::message_passing::IClientConnection::State const state) {
        switch (state) {
            case score::message_passing::IClientConnection::State::kReady: {
                Message_frame<Connect> connect_msg;
                connect_msg.payload.find_service_elements = m_find_service_elements;
                connect_msg.payload.shared_memory_configs = m_server_shared_memory_configs;
                connect_msg.payload.identifier = m_identifier;
                (void)send(connect_msg);

                break;
            }
            case score::message_passing::IClientConnection::State::kStopped: {
                switch (m_channel->GetStopReason()) {
                    case score::message_passing::IClientConnection::StopReason::
                        kUserRequested:  // fall through
                    case score::message_passing::IClientConnection::StopReason::
                        kPermission:  // fall through
                    case score::message_passing::IClientConnection::StopReason::
                        kShutdown:  // fall through
                        // Do not attempt to restart the channel in these cases as they indicate an
                        // intentional stop from either the client or server side.
                        m_stopped = true;
                        break;
                    default:
                        // For other stop reasons, attempt to restart the channel to allow recovery
                        // from transient issues.
                        m_channel->Restart();
                        break;
                }
                break;
            }
            case score::message_passing::IClientConnection::State::kStarting:
            case score::message_passing::IClientConnection::State::kStopping:
            default:
                m_connected = false;
                // Remove client to prevent send() being called by m_binding_base and racing
                // with the engine thread closing the underlying file descriptor.
                m_binding_base.remove_client(client_id);
                break;
        }
    }

    void on_receive_message(score::cpp::span<std::uint8_t const> data) noexcept {
        if (data.empty() || m_channel == nullptr) {
            return;  // Ignore empty messages or when destructor runs
        }

        auto message_type = get_message_type(data[0]);

        if (Message_type::Connect_reply == message_type) {
            auto msg_opt = check_and_convert<Connect_reply>(data);
            if (!msg_opt) {
                // Invalid message - log and ignore
                return;
            }

            handle_connect_reply_message(*msg_opt);
        }
        m_binding_base.on_receive_message(client_id, *this, data);
    }

    void handle_connect_reply_message(Connect_reply const& msg) {
        SCORE_LANGUAGE_FUTURECPP_ASSERT(msg.status);
        m_connected = msg.status;

        if (m_connected) {
            m_binding_base.add_client(client_id, *this);
        }
    }

   private:
    std::atomic<bool> m_connected{false};
    std::atomic<bool> m_stopped{false};
    // There is only ever one connection: from this instance to the server
    constexpr static Client_id client_id{0};
    Gateway_ipc_binding_base m_binding_base;
    score::cpp::pmr::unique_ptr<score::message_passing::IClientConnection> m_channel;
    Find_service_elements m_find_service_elements;
    Client_identifier m_identifier;
    Shared_memory_configs m_server_shared_memory_configs;
};

}  // namespace

std::unique_ptr<Gateway_ipc_binding_client> Gateway_ipc_binding_client::create(
    score::socom::Runtime& runtime,
    score::cpp::pmr::unique_ptr<score::message_passing::IClientConnection> connection,
    Shared_memory_manager_factory::Uptr slot_manager, Find_service_elements find_service_elements,
    Shared_memory_configs server_shared_memory_configs, std::string_view identifier) noexcept {
    SCORE_LANGUAGE_FUTURECPP_ASSERT(connection && "Connection must not be null");

    auto identifier_opt = fixed_string_from_string<Client_identifier>(identifier);
    SCORE_LANGUAGE_FUTURECPP_ASSERT(identifier_opt &&
                                    "Identifier exceeds maximum size for Client_identifier");

    return std::make_unique<Gateway_ipc_binding_client_impl>(
        runtime, std::move(connection), std::move(slot_manager), find_service_elements,
        *identifier_opt, server_shared_memory_configs);
}

}  // namespace score::gateway_ipc_binding
