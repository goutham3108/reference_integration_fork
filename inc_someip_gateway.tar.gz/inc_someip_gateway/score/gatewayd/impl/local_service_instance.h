/********************************************************************************
 * Copyright (c) 2025 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/

#ifndef IMPL_GATEWAYD_LOCAL_SERVICE_INSTANCE
#define IMPL_GATEWAYD_LOCAL_SERVICE_INSTANCE

#include <map>
#include <memory>
#include <string_view>
#include <vector>

#include "score/config/mw_someip_config_generated.h"
#include "score/mw/com/types.h"
#include "score/socom/server_connector.hpp"

namespace score::socom {
class Runtime;
}  // namespace score::socom

struct score_com_serializer;

namespace score::someip_gateway::gatewayd {

/// \brief Instance of a locally available service
/// \details This class represents a service instance that is provided by an application
///          running on the same ECU. It manages the communication between the local service
///          and the someipd daemon, which handles the actual SOME/IP network protocol.
///          The class uses an IPC proxy for local communication with the service providing
///          application and coordinates with the SOME/IP message skeleton to forward messages to
///          the someipd daemon, ultimately making the local service accessible to remote ECUs.
class LocalServiceInstance {
   public:
    /// \brief Creates a LocalServiceInstance
    /// \param service_instance_config Configuration for this service instance
    /// \param service_type_config Configuration for the service type of this instance
    /// \param ipc_proxy Generic proxy for IPC communication with the local service
    /// \param socom_runtime SOCom runtime used to create the server connector
    /// \return Result containing the created instance on success, or an error on failure
    /// \details This factory method creates a local service instance with the necessary
    ///          components to forward local service messages to the someipd daemon, which
    ///          then handles the SOME/IP network communication with remote ECUs.
    static Result<std::unique_ptr<LocalServiceInstance>> Create(
        std::shared_ptr<const mw_someip_config::ServiceInstance> service_instance_config,
        std::shared_ptr<const mw_someip_config::ServiceType> service_type_config,
        score::mw::com::GenericProxy&& ipc_proxy, socom::Runtime& socom_runtime);

    /// \brief Asynchronously creates a local service instance
    /// \param service_instance_config Configuration for the service instance to create
    /// \param service_type_config Configuration for the service type of the instance to create
    /// \param socom_runtime SOCom runtime used to create the server connector
    /// \param instances Reference to the vector to store the created local service instance
    /// \return Result containing a FindServiceHandle on success, or an error on failure
    /// \details This static factory method asynchronously searches for and creates a local
    ///          service instance. It performs service discovery on the local ECU and, when
    ///          found, constructs a LocalServiceInstance object and adds it to the instances
    ///          vector. The returned FindServiceHandle can be used to manage the asynchronous
    ///          operation.
    static Result<mw::com::FindServiceHandle> CreateAsyncLocalServices(
        std::shared_ptr<const mw_someip_config::ServiceInstance> service_instance_config,
        std::shared_ptr<const mw_someip_config::ServiceType> service_type_config,
        socom::Runtime& socom_runtime,
        std::vector<std::unique_ptr<LocalServiceInstance>>& instances);

    LocalServiceInstance(const LocalServiceInstance&) = delete;
    LocalServiceInstance& operator=(const LocalServiceInstance&) = delete;
    LocalServiceInstance(LocalServiceInstance&&) = delete;
    LocalServiceInstance& operator=(LocalServiceInstance&&) = delete;

   private:
    /// \brief Private constructor
    LocalServiceInstance(
        std::shared_ptr<const mw_someip_config::ServiceInstance> service_instance_config,
        std::shared_ptr<const mw_someip_config::ServiceType> service_type_config,
        score::mw::com::GenericProxy&& ipc_proxy,
        score::socom::Enabled_server_connector::Uptr server_connector);

    /// Configuration for this service instance
    std::shared_ptr<const mw_someip_config::ServiceInstance> service_instance_config_;
    /// Configuration for the service type of this instance
    std::shared_ptr<const mw_someip_config::ServiceType> service_type_config_;
    /// Generic proxy for IPC communication with the local service providing application
    score::mw::com::GenericProxy ipc_proxy_;
    /// SOCom server connector for handling communication with the someipd daemon
    score::socom::Enabled_server_connector::Uptr server_connector_;

    struct EventContext {
        const mw_someip_config::Event* config;
        const ::score_com_serializer* serializer;
        const socom::Event_id socom_event_id;
    };
    std::map<std::string_view, EventContext> event_contexts_;

    static score::cpp::move_only_function<void(score::mw::com::SamplePtr<void>)>
    create_process_sample_callback(LocalServiceInstance* instance_ptr,
                                   EventContext const& event_context);
};
}  // namespace score::someip_gateway::gatewayd

#endif  // IMPL_GATEWAYD_LOCAL_SERVICE_INSTANCE
