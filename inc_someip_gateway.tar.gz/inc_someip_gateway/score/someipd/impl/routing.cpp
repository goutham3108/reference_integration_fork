/********************************************************************************
 * Copyright (c) 2026 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/

#include "routing.h"

#include <chrono>
#include <functional>
#include <score/assert.hpp>
#include <thread>
#include <utility>

#include "score/mw/log/logging.h"
#include "score/someip/constants.h"
#include "score/someip/someip_error.h"

namespace score::someipd {

using score::someip::kAnyInstance;

Routing::Routing(std::shared_ptr<const score::mw_someip_config::Root> config)
    : config_(std::move(config)) {}

Routing::Routing(Routing&&) noexcept = default;

Routing& Routing::operator=(Routing&& other) noexcept {
    if (this != &other) {
        SCORE_LANGUAGE_FUTURECPP_ASSERT(!processing_thread_.joinable());
        config_ = std::move(other.config_);
        application_ = std::move(other.application_);
        payload_ = std::move(other.payload_);
        processing_thread_ = std::move(other.processing_thread_);
    }
    return *this;
}

Result<Routing> Routing::Create(std::shared_ptr<const score::mw_someip_config::Root> config) {
    Routing routing(std::move(config));
    auto runtime = vsomeip::runtime::get();
    routing.application_ = runtime->create_application("someipd");
    if (!routing.application_->init()) {
        score::mw::log::LogFatal() << "[someipd] vsomeip application initialization failed";
        return MakeUnexpected(score::someip::Errc::kInitializationFailed);
    }
    routing.payload_ = runtime->create_payload();
    score::mw::log::LogInfo() << "[someipd] vsomeip application initialized successfully";

    return Result<Routing>{std::move(routing)};
}

void Routing::SetupOfferings() {
    for (const auto* const service_type : *config_->service_types()) {
        const auto* service_instances = service_type->local_service_instances();
        if ((service_instances != nullptr) && !service_instances->empty()) {
            for (const auto* const local_service_instance :
                 *service_type->local_service_instances()) {
                for (const auto* const event : *service_type->events()) {
                    std::set<vsomeip::eventgroup_t> groups;
                    auto const* eventgroup_ids = event->eventgroup_ids();
                    // Treat empty vector the same as absent: fall back to event_id as eventgroup.
                    if (eventgroup_ids != nullptr && !eventgroup_ids->empty()) {
                        for (auto group_id : *eventgroup_ids) {
                            groups.insert(group_id);
                        }
                    } else {
                        // Fallback: use event_id as group when no eventgroup_ids configured.
                        groups.insert(event->event_id());
                    }
                    application_->offer_event(service_type->service_id(),
                                              local_service_instance->instance_id(),
                                              event->event_id(), groups);
                }
                score::mw::log::LogInfo()
                    << "[someipd] Offering service 0x"
                    << score::mw::log::LogHex16{service_type->service_id()} << " instance 0x"
                    << score::mw::log::LogHex16{local_service_instance->instance_id()};
                application_->offer_service(service_type->service_id(),
                                            local_service_instance->instance_id(),
                                            service_type->service_version_major());
            }
        }
    }
}

InstanceId Routing::LookupInstanceId(ServiceId service_id) const {
    for (const auto* const service_type : *config_->service_types()) {
        if (service_type->service_id() != service_id) {
            continue;
        }
        return service_type->local_service_instances()->Get(0)->instance_id();
    }
    return kAnyInstance;
}

void Routing::ProcessMessages(std::atomic<bool>& shutdown_requested) {
    // TODO: Replace sleep loop with SOCom client_connector callbacks
    while (!shutdown_requested.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    score::mw::log::LogInfo() << "[someipd] Message loop exited, shutting down...";
}

void Routing::Run(std::atomic<bool>& shutdown_requested, std::function<void()> on_registered) {
    application_->register_state_handler([this, on_registered = std::move(on_registered)](
                                             vsomeip::state_type_e state) {
        if (state == vsomeip::state_type_e::ST_REGISTERED) {
            score::mw::log::LogInfo() << "[someipd] Application registered with routing daemon.";
            score::mw::log::LogInfo() << "[someipd] Setting up offerings...";
            SetupOfferings();
            if (on_registered) {
                on_registered();
            }
        }
    });
    score::mw::log::LogInfo() << "[someipd] Starting network stack processing...";
    processing_thread_ = std::thread([this]() { application_->start(); });
    score::mw::log::LogInfo() << "[someipd] Network stack started, entering message loop.";
    ProcessMessages(shutdown_requested);
    score::mw::log::LogInfo() << "[someipd] Stopping network stack processing...";
    if (application_) {
        application_->stop();
    }
    if (processing_thread_.joinable()) {
        processing_thread_.join();
    }

    score::mw::log::LogInfo() << "[someipd] Network stack stopped.";
}

}  // namespace score::someipd
