..
   # *******************************************************************************
   # Copyright (c) 2025 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

SOMEIP Gateway Architecture
===========================

Feature Definition
------------------

.. toctree::
   :maxdepth: 1

   features.rst

Component Definition
--------------------

.. toctree::
   :maxdepth: 1

   components.rst

Design decisions
----------------

.. toctree::
   :maxdepth: 1

   dec_someipgw_registration.rst
   dec_someip_api_abstraction.rst
   dec_ipc_implementation.rst
   tc8_conformance_testing.rst
